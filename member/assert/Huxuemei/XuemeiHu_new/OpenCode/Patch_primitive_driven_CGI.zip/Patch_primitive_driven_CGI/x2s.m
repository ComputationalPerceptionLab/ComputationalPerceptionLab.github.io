function [s]=x2s(x,idx,Base)
%

opts = spgSetParms('verbosity',0);
pn=size(idx,2);
bn=size(Base,2);
s=zeros(bn,pn);
for i=1:pn
    x_p=x(idx(:,i));
    s(:,i)=spg_bp(Base,x_p,opts);
end
s=s(:);

end
