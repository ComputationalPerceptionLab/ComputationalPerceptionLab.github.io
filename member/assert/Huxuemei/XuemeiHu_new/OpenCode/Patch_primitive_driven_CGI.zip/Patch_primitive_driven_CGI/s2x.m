function [x]=s2x(s,Base,idx,ps_x,ps_y)
    bn=size(Base,2);
    pn=size(idx,2);
    s=reshape(s,[bn,pn]);
    x=zeros(ps_y*ps_x,1);
    for i=1:pn
        x(idx(:,i))=Base*s(:,i);
    end
end
