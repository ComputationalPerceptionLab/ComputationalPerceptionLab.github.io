function [idx,pn]=gen_idx(ps_x,ps_y,ps)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generate the index to rearrange the vectorized image by patch cell
% plays the role of matrix R in the paper
% px is the row size of the 2D image
% py is the col size of the 2D image
% ps is the patch size, we assume the path size to be ps*ps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    idx=[];
    px=ps;
    py=ps;
    pny=ps_y/py;
    pnx=ps_x/px;
    for pix =1:pnx
        for piy =1:pny
           [xx,yy]=meshgrid( (pix-1)*px+(1:px),(piy-1)*py+(1:py)  );
           idx=[idx,(xx(:)-1)*ps_y+yy(:)];
        end
    end
    pn=pnx*pny;  % the total patch number
    
end
