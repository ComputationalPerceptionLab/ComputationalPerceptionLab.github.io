function [c]=pcgi(H,P,y,c_0,lambda,mu_0,mu_bar,rho,max_iter,tol,plot_flag,pinv_mat)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Optimize objective function: min ||Hc||_1+lambda||c||_1 s.t. Pc=y
% Eq.(8) in "patch primitive driven compressive ghost imaging"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

c=c_0;
n=length(c);
w=H*c;
v=c;
r=zeros(size(w));
s=zeros(size(v));
t=zeros(size(y));

object_kp=norm(H*c,1)+lambda*norm(c,1);

mu=mu_0;
converged=false;
iter=0;
% pinv_mat=pinv(H'*H+P'*P+eye(n));

if plot_flag==1
    figure;
    o=object_kp;
end

while ~converged
    iter=iter+1;
    
    % update w
    tmp=H*c-1/mu*r;flag1=tmp>1/mu;flag2=tmp<-1/mu;    
    w=(tmp-1/mu).*flag1+(tmp+1/mu).*flag2;    
    
    % update v
    tmp=c-1/mu*s;flag1=tmp>lambda/mu;flag2=tmp<-lambda/mu;
    v=(tmp-lambda/mu).*flag1+(tmp+lambda/mu).*flag2;
    
    % update c
    c=pinv_mat*(H'*(w+1/mu*r)+(v+1/mu*s)+P'*(y+1/mu*t));
    
    % update r,s,t
    r=r+mu*(w-H*c);
    s=s+mu*(v-c);
    t=t+mu*(y-P*c);
    
    %tmp=w-H*c;
    %resid_1=norm(tmp(:),2)
    %tmp=v-c;
    %resid_2=norm(tmp(:),2)
    %tmp=y-P*c;
    %resid_3=norm(tmp(:),2)
    
    % update mu
    mu=min(mu_bar,mu*rho); 
    
    % stop criterion
    object_k=object_kp;
    object_kp=norm(H*c,1)+lambda*norm(c,1);
    stop_c1=object_k-object_kp;
    stop_c2=norm(object_k-object_kp)/norm(object_kp);
    %[stop_c1,stop_c2]
    if ((stop_c1<tol && stop_c1>=0) || abs(stop_c1)<tol/100) ...
            && stop_c2<tol  && iter>20
        converged=true;
        disp('iteration is converged');
    elseif iter>max_iter
        converged=true;
        disp('iter number reached maximun number');
    end        

    if plot_flag==1
            o=[o,object_kp];
%             subplot(121);
            plot(o);title('object value');
%             subplot(122);imshow(reshape(x,[N1,N2]));title('rst img');
            pause(0.1);
    end
    
end

if plot_flag==1
    close;
end

end
