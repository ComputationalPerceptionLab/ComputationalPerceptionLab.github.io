clc;close all;clear all;
addpath(genpath(pwd));

%% load in coded pattern P, which is of size [row, col, pattern_number]
load('_pattern/P.mat'); 
[row,col,pattern_number]=size(P);
pattern=reshape(P, [row*col,pattern_number]);
pattern=double(pattern'); % measurement pattern

%% patch size, 8*8 square
ps=8;

%% load in dictionary, the dictionary is trained with the code in _image_helper/fast_sc
%   REFER TO : "Efficient sparse coding algorithms" for details of PATCH DICTIONARY LEARNING
load(['_patch_dictionary/Dl_lam_1.mat']);
B(:,find(sum(abs(B),1)==0))=[]; 
Base=[B,ones(size(B,1),1)]; 
display_dictionary(Base,ps); 
title('dictionary');

%% generate Psi matrix, Psi is matrix operator for calculating the first order gradient of the image, 
%   implemented on vectorized image
gradient_order=1;
Psi=generate_Psi(col,row,gradient_order);
[idx,pn]=gen_idx(row,col,ps);

%% generate Psi_R_D matrix
Psi_R=Psi(:,idx(:)');
D=[];
for i=1:pn
    D=blkdiag(D,Base);
end
Psi_R_D=Psi_R*D;

%% generate Phi, Phi_R_D matrix
% ssr: sub-Nyquist sampling ratio
ssr=1; 
m=ceil(ssr*col*row); % measurement number
Phi=double(pattern(1:m,:));
Phi_R=Phi(:,idx(:)');
Phi_R_D=Phi_R*D; 

%% optimization main part
%   REFER TO FOR UNDERSTANDING THE ALGORITHM:
%   "Distributed optimization and statistical learning via the
%   alternating direction method of multipliers"
%   "The Augmented Lagrange Multiplier Method for Exact Recovery of Corrupted Low-Rank Matrices"

%   precalculate pinv_mat for pcgi function, to accelerate the optimization
%   (time consuming part)
pinv_mat=pinv(Psi_R_D'*Psi_R_D+Phi_R_D'*Phi_R_D+eye(size(Phi_R_D,2)));

% load in your measurement data here 
% FOR SIMULATION: calculate measurement=pattern*img_gt(:) )
%   load('_data/img_gt.mat'); measurement=Phi*img_gt(:);
% FOR PHYSICAL EXPERIMENT, vectorize the measurement (size [m,1]) 
%   load('data/measurement.mat');
Y=measurement;

% use simple TVAL3 algorithm, and use the result as the initial value
% of my reconstruction algorithm, to speed up the convergence
% REFER TO: http://www.caam.rice.edu/~optimization/L1/TVAL3/
opts=[];opts.nonneg=true;opts.TVnorm = 1;
[img_tval,~]=TVAL3( Phi,Y,col,row,opts);
x_tval=img_tval(:);

% optimization parameters?the optimization parameters should be tuned for different ground truth image
% calculate the balancing coefficient lambda for pcgi optimization
s_tval=x2s(x_tval,idx,Base); 
if norm(s_tval,1)>1e-4 
    lambda_0=norm(Psi_R_D*s_tval,1)/norm(s_tval,1); 
else
    lambda_0=1;
end
% mu related
mu_0=1;
mu_bar=1e7;
rho=1.05;
% max iterations, tol is tolerance for deciding if the objective function is non longer changing.
max_iter=500;
tol=1e-3; 
plot_flag=0;

% optimization 
[s_pcgi]=pcgi(Psi_R_D,Phi_R_D,Y,s_tval,lambda_0,...
                mu_0,mu_bar,rho,max_iter,tol,plot_flag,pinv_mat);
x_pcgi=s2x(s_pcgi,Base,idx,row,col);
img_pcgi=reshape(x_pcgi,[row,col]);

% save results
save_path='_results/';
mkdir(save_path);
save([save_path 'all_data.mat']);

%%
