 function [z_tp,z1,z2]=ConvSCD(S,tp,kernel1,kernel2,display,logsum_flag,tolerance,max_iter_num)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ConvSCD algorithm description
%%% Objective:
%%% minimize_z \sum_n ||z^(1)_n||_ls+\alpha\sum_m ||z^(2)_m||_ls 
%%%       +\lambda||p-\sum_n{z^(1)_n*k^(1)_n}-\sum_m{z^(2)_m*k^(1)_m}||
%%% note:
%%%      \alpha for treating the balance between reflections and sss
%%%      \lambda for balace fitting and reconstruction sparsity
%%%
%%% IO:
%%% input:    
%%%        tp: time profile
%%%        kernel1: kernels; N*ker_len
%%%        kernel2: kernels; M*ker_len
%%%        S: kernel^T*kernel; precompute outside the algorithm for speed
%%%        display: display the error of each iteration
%%%        logsum_flag: using l1 norm sparisity metric or logsum sparsity
%%%                     metric
%%%        tolerance: fitting error tolerance
%%%        max_iter_num: maximum iter number
%%% ouput:   
%%%        z_tp: z
%%%        z1,z2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% parameters and controling variable
% lambda updating controler 
% lambda=lambda*rho
lambda_0=1e-1;
rho=1.1;
% lambda_delta=1;
lambda_bar=1e7;

%force the reconstruction to be positive
force_positive=1;

%log_sum related
p=1;

%\alpha
alpha=1.2;

% tol_updating: tolerance |z_kp-z_k|/|z_k|<tolerance means converges
% tol_fitting: time profile fitting tolerance
if nargin<7
    tol_updating=5e-2;
else
    tol_updating=tolerance;
end
tol_fitting=tol_updating*1.2;% less strict

%maximum iteration number
if nargin<8
    max_iter=1000;
else
    max_iter=max_iter_num;
end

%% 
% combine kernel
kernel=[kernel1;kernel2];

%
sig_len=length(tp);
[ker_num,ker_len]=size(kernel);

%weighing matrix for z
M_a=ones(ker_num,sig_len-ker_len+1);
for i=size(kernel,1)+1:ker_num
    M_a(i,:)=alpha;
end
                                                                                                                                                                                                                                                                                                                                                      
%outer loop: 

%%
converged_out=false;
iter_out=0;
z_tp=zeros(ker_num,sig_len-ker_len+1);
stopC=[];
w=ones(ker_num,sig_len-ker_len+1);

while ~converged_out
iter_out=iter_out+1;
lambda=lambda_0;
% z_kp=z_tp; %%may be need to revised
z_kp=zeros(ker_num,sig_len-ker_len+1);

beta=zeros(ker_num,sig_len-ker_len+1);
for i=1:ker_num
    tmp=conv(kernel(i,end:-1:1),tp);
    beta(i,:)=tmp(ker_len:sig_len);
end

converged_inner=false;
iter_in=0;
while ~converged_inner
    iter_in=iter_in+1;
    z_star=sign(beta).*max(abs(beta)-w.*M_a./(2*lambda),0);

    %force positive
    if force_positive==1
       z_star(find(z_star<1e-5))=0;
    end

    tmp=abs(z_kp-z_star);
    [max_v1,max_p1]=max(tmp,[],2);
    [max_v2,max_p2]=max(max_v1);
    k=max_p2;%��k����
    j=max_p1(max_p2);%��j��λ��
    b_tmp=beta(k,j);
    e_j=zeros(1,sig_len-ker_len+1);
    e_j(j)=1;
    tmp1=squeeze(S(:,k,:));%K*(2s-1)
    tmp2=zeros(ker_num,sig_len-ker_len+1);
    for i=1:ker_num
        tmp3=conv(tmp1(i,:),e_j);
        tmp2(i,:)=tmp3(ker_len:sig_len);
    end
    beta=beta+(z_kp(k,j)-z_star(k,j))*tmp2;
    beta(k,j)=b_tmp;
    z_k=z_kp;
    z_kp(k,j)=z_star(k,j);
    
    %%
    stopCriterion1=norm(z_k-z_kp,2)/norm(z_k,2);
    sig_reconst=zeros(1,length(tp));
    for i=1:ker_num
    sig_reconst=sig_reconst+conv(kernel(i,:),z_kp(i,:));
    end
    stopCriterion2=norm(sig_reconst-tp,2)/norm(tp,2);
    if stopCriterion1<tol_updating && stopCriterion2<tol_fitting
      converged_inner=true;
    end
    if stopCriterion1<1e-10
        converged_inner=true;
    end
    if ~converged_inner && iter_in>=max_iter
      disp('Maximum iterations reached');
      converged_inner=true;
    end             
    lambda=min(rho*lambda,lambda_bar);
    
    %display
    if display==1
        iter_in
        stopCriterion1
        stopCriterion2
    end
end

%logsum norm or l_1 norm
if logsum_flag==0
    converged_out=true;
end

%update
z_t=z_tp;
z_tp=z_kp;

%stop criterion: out loop
stopC_out=norm(z_tp-z_t,2)/norm(z_t,2);
stopC=[stopC, stopC_out];
if stopC_out<tol_updating
    converged_out=true;
end
if ~converged_out && iter_out>max_iter
      disp('Maximum iterations reached');
      converged_out=true;
end  

%log_sum: refine reconstruction result
%      w: log-sum reweighing controller
tmp=max(z_tp(:));
thres_ratio=1e-4;
w=z_tp+thres_ratio*tmp;
w=(tmp*w.^(-1)*(1+thres_ratio)).^p;
end

z1=z_tp(1:size(kernel1,1),:);
z2=z_tp(size(kernel1,1)+1:size(kernel1,1)+size(kernel2,1),:);
end