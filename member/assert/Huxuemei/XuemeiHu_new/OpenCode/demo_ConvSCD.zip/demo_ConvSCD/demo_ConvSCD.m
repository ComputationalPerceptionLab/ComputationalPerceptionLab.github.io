%% main function
clc;
% clear all;
close all;

%% kernels
ker_len=200;

% k1
k1_sigma_max=10;
k1_sigma_min=1;
k1_sigma=linspace(k1_sigma_min,k1_sigma_max,100);
k1=[];

for i=1:length(k1_sigma)
  tmp=gaussmf([1:ker_len],[k1_sigma(i),floor(ker_len/2)+1]);
  tmp=tmp/norm(tmp,2);
  k1=[k1;tmp];
end

% k2
k2_coef_max=0.05;% 
k2_coef_min=0.01;% 
k2_coef=linspace(k2_coef_min,k2_coef_max,100);
k2=[];

% for faster reconstruction we use the mode sigma=5 instead of enumerate 
% the sigma from 1 to 10 to construct the kernel
% type 2(the sigma distribution centers at 5)
c_sigma=5;
c_len=51;
c=gaussmf([1:c_len],[c_sigma,ceil(c_len/2)]);

x_vec=[1:ker_len-c_len+1];
for i=1:length(k2_coef)
   tmp=exp(-k2_coef(i)*x_vec);
   tmp=conv(tmp,c);
   tmp=tmp/norm(tmp,2);
   k2=[k2;tmp];
end
kernel=[k1;k2];
 
%% precompute for ConvSCD
if ~exist('K','var')
    K=size(kernel,1);
    for i=1:K
        for j=1:K
            tmp1=kernel(i,end:-1:1);
            tmp2=kernel(j,:);
            S(i,j,:)=conv(tmp1,tmp2);
        end
    end
end
disp('precompute finished'); 


%% time profile simulated without noise:
% time_profile_type=input('input a number in 1-6 to choose a certain time profile:');
for time_profile_type=1:6
    
noise=false;    
tp_ori=gen_time_profile(time_profile_type,512,noise);
figure;plot(tp_ori);title('original time profile');
sig_len=length(tp_ori);

%%%optimization
% augment signal
tp_aug=zeros(1,sig_len+2*ker_len);
tp_aug(ker_len+1:ker_len+sig_len)=tp_ori';

% ConvSCD
display=true;
logsum_flag=true;
[z,z1,z2]=ConvSCD(S,tp_aug,k1,k2,logsum_flag,display);

%visualize the recosntruction result, refer to plot_result.m
plot_result;
end

%% time profile simulated with noise:
% time_profile_type=input('input a number in 1-6 to choose a certain time profile:');
for time_profile_type=1:6
    
noise=true;    
tp_ori=gen_time_profile(time_profile_type,512,noise);
figure;plot(tp_ori);title('original time profile');
sig_len=length(tp_ori);

%%%optimization
% augment signal
tp_aug=zeros(1,sig_len+2*ker_len);
tp_aug(ker_len+1:ker_len+sig_len)=tp_ori';

% ConvSCD
display=true;
logsum_flag=true;
[z,z1,z2]=ConvSCD(S,tp_aug,k1,k2,display,logsum_flag);

%visualize the recosntruction result
plot_result;
end

%% time profile in fig 4
load('fig_4_tp.mat');
figure;plot(tp_ori);title('original time profile');
sig_len=length(tp_ori);

%%%optimization
% augment signal
tp_aug=zeros(1,sig_len+2*ker_len);
tp_aug(ker_len+1:ker_len+sig_len)=tp_ori';

% ConvSCD
display=true;
logsum_flag=true;
[z,z1,z2]=ConvSCD(S,tp_aug,k1,k2,display,logsum_flag);

%visualize the recosntruction result
plot_result;

%% time profile in fig 5
load('fig_5_tp.mat');
figure;plot(tp_ori);title('original time profile');
sig_len=length(tp_ori);

%%%optimization
% augment signal
tp_aug=zeros(1,sig_len+2*ker_len);
tp_aug(ker_len+1:ker_len+sig_len)=tp_ori';

% ConvSCD
display=true;
logsum_flag=true;
[z,z1,z2]=ConvSCD(S,tp_aug,k1,k2,display,logsum_flag);

%visualize the recosntruction result
plot_result;
