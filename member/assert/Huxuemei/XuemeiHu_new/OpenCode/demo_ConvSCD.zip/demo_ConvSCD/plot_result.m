%% plot result
mask=z>(0.05*max(max(z)));
z_masked=z.*mask;

z1_masked=z_masked(1:size(k1,1),:);
z2_masked=z_masked(size(k1,1)+1:size(k1,1)+size(k2,1),:);

%
figure;
subplot(121);spy(z1_masked',10);title('z1 masked');
subplot(122);spy(z2_masked',10);title('z2 masked');

%
figure;
plot(tp_ori,'b');hold on;
% reflection component plotting
[x1_masked,y1_masked]=find(z1_masked>0);
z1_masked_nonzero=z1_masked(find(z1_masked>0));
disp('z1_nonzero');
result1=[x1_masked,y1_masked,z1_masked_nonzero]
color_vec=spring;
for i=1:length(x1_masked)   
    z1_tmp=zeros(size(z,2),1);
    z1_tmp(y1_masked(i))=z1_masked(x1_masked(i),y1_masked(i));
    reflection_component_tmp=conv(k1(x1_masked(i),:),z1_tmp);
    reflection_component= reflection_component_tmp(ker_len+1:ker_len+sig_len);
    plot(reflection_component,'Color',color_vec(mod(25*i,length(color_vec)),:)); hold on;
end

% sss component plotting
[x2_masked,y2_masked]=find(z2_masked>0);
z2_masked_nonzero=z2_masked(find(z2_masked>0));
disp('z2_nonzero');
result2=[x2_masked,y2_masked,z2_masked_nonzero]
color_vec=summer;
for i=1:length(x2_masked)   
    z2_tmp=zeros(size(z,2),1);
    z2_tmp(y2_masked(i))=z2_masked(x2_masked(i),y2_masked(i));
    sss_component_tmp=conv(k2(x2_masked(i),:),z2_tmp);
    sss_component=sss_component_tmp(ker_len+1:ker_len+sig_len);
    plot(sss_component,'Color',color_vec(mod(25*i,length(color_vec)),:)); hold on;
end
fig_name=['reconstruction result originally'];
title(fig_name);

figure;
plot(tp_ori);hold on;

%reflection component
[x1_masked,y1_masked]=find(z1_masked>0);
z1_masked_nonzero=z1_masked(find(z1_masked>0));
disp('z1_nonzero');
result1=[x1_masked,y1_masked,z1_masked_nonzero]%display the nonzero component for check
color_vec=spring;

reflection_component_tmp=zeros(sig_len+2*ker_len,1);
reflection_count=0;
for i=1:length(x1_masked)   
    z1_tmp=zeros(size(z,2),1);
    z1_tmp(y1_masked(i))=z1_masked(x1_masked(i),y1_masked(i));
    reflection_component_tmp=reflection_component_tmp+conv(k1(x1_masked(i),:),z1_tmp);
    if i==length(x1_masked) || y1_masked(i+1)>y1_masked(i)+10 %adding the near component together
        reflection_count=reflection_count+1;
        reflection_component= reflection_component_tmp(ker_len+1:ker_len+sig_len);
        plot(reflection_component,'Color',color_vec(mod(25*reflection_count,length(color_vec)),:)); hold on;
        reflection_component_tmp=zeros(sig_len+2*ker_len,1);
    end
end

%sss component, add together
[x2_masked,y2_masked]=find(z2_masked>0);
z2_masked_nonzero=z2_masked(find(z2_masked>0));
disp('z2_nonzero');
result2=[x2_masked,y2_masked,z2_masked_nonzero]
sss_component_tmp=zeros(sig_len+2*ker_len,1);
for i=1:length(x2_masked)   
    z2_tmp=zeros(size(z,2),1);
    z2_tmp(y2_masked(i))=z2_masked(x2_masked(i),y2_masked(i));
    sss_component_tmp=sss_component_tmp+conv(k2(x2_masked(i),:),z2_tmp);
end
sss_component=sss_component_tmp(ker_len+1:ker_len+sig_len);
plot(sss_component,'Color',[0,1,0]); hold on;
fig_name=['reconstruction result treated'];
title(fig_name);