%% main function
clc;
% clear all;
close all;

%% kernels
ker_len=200;

% k1
k1_sigma_max=10;
k1_sigma_min=1;
k1_sigma=linspace(k1_sigma_min,k1_sigma_max,100);
k1=[];

for i=1:length(k1_sigma)
  tmp=gaussmf([1:ker_len],[k1_sigma(i),floor(ker_len/2)+1]);
  tmp=tmp/norm(tmp,2);
  k1=[k1;tmp];
end

% k2
k2_coef_max=0.05;% can be adjusted
k2_coef_min=0.01;% can be adjusted
k2_coef=linspace(k2_coef_min,k2_coef_max,100);
k2=[];

% for faster reconstruction we use the mode sigma=5 instead of enumerate 
% the sigma from 1 to 10 to construct the kernel
% type 2(the sigma distribution centers at 5)
c_sigma=5;
c_len=51;
c=gaussmf([1:c_len],[c_sigma,ceil(c_len/2)]);

x_vec=[1:ker_len-c_len+1];
for i=1:length(k2_coef)
   tmp=exp(-k2_coef(i)*x_vec);
   tmp=conv(tmp,c);
   tmp=tmp/norm(tmp,2);
   k2=[k2;tmp];
end
kernel=[k1;k2];
 
%% precompute for ConvSCD cause they are same for all the pixel
if ~exist('K','var')
    K=size(kernel,1);
    for i=1:K
        for j=1:K
            tmp1=kernel(i,end:-1:1);
            tmp2=kernel(j,:);
            S(i,j,:)=conv(tmp1,tmp2);
        end
    end
end
disp('precompute finished'); 

%% demo the sparity enhancement of using log-sum norm
noise=true; 
time_profile_type=2;
tp_ori=gen_time_profile(time_profile_type,512,noise);
figure;plot(tp_ori);title('original time profile');
sig_len=length(tp_ori);


%%%optimization
% augment signal
tp_aug=zeros(1,sig_len+2*ker_len);
tp_aug(ker_len+1:ker_len+sig_len)=tp_ori';

%l1 sparsity metric
display=true;
logsum_flag=false;
[z,z1,z2]=ConvSCD(S,tp_aug,k1,k2,display,logsum_flag);
plot_result

%ls sparsity metric
display=true;
logsum_flag=true;
[z,z1,z2]=ConvSCD(S,tp_aug,k1,k2,display,logsum_flag);
plot_result


