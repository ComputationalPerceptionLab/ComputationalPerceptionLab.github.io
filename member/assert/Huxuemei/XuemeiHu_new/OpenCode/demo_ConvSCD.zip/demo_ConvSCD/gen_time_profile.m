function [tp]=gen_time_profile(time_profile_type,tp_len,noise_flag)
%%%%%%%%%%%%%%%%%%%%%%function description%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Objective:
%%%      generate time profile for demonstration of the algorithm ConvSCD
%%%      there are mainly six types of time profile which composed differently
%%%      by reflections and sss component
%%% IO:
%%% input:    
%%%      type_profile_type:  index for the time profile type 1 to 6
%%%      tp_len: the length of the time profile
%%%      noise_flag: add noise or not, false-noise free, true-add noise 
%%% ouput:   
%%%      tp: time profile
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tp_g_pos=[];
tp_g_intensity=[];
tp_g_sigma=[];
tp_e_pos=[];

tp_g=zeros(1,tp_len);
tp_e=zeros(1,tp_len);

switch time_profile_type
    case 1
        tp_g_pos=[200];
        tp_g_intensity=[1];
        tp_g_sigma=6.3;
    case 2
        tp_g_pos=[200];
        tp_g_intensity=[1];
        tp_g_sigma=5.5;          
        e_coef=0.025;
        tp_e_pos=[240];
        tp_e_a=0.02;      
    case 3
        tp_g_pos=[200,300];
        tp_g_intensity=[1,0.2];
        tp_g_sigma=[5.1,5.1]; 
    case 4
        tp_g_pos=[200,300];
        tp_g_intensity=[1, 0.2];
        tp_g_sigma=[4,5];          
        e_coef=0.03;
        tp_e_pos=[250];
        tp_e_a=0.025;       
    case 5
        tp_g_pos=[200,250,300];
        tp_g_intensity=[1,0.5,0.25];
        tp_g_sigma=[4,5,8];  
    case 6
        tp_g_pos=[200,290,350];
        tp_g_intensity=[1,0.45,0.2];
        tp_g_sigma=[4,5,6];          
        e_coef=0.025;
        tp_e_pos=[230];
        tp_e_a=0.025; 
end

if numel(tp_g_pos)~=0
    for i=1:length(tp_g_pos)
        tmp=zeros(1,tp_len);
        tmp(tp_g_pos(i))=tp_g_intensity(i);
        u=gaussmf([1:51],[tp_g_sigma(i),26]);
        tmp=conv(tmp,u,'same')/sum(u);
        tp_g=tp_g+tmp;
    end
end

u=gaussmf([1:51],[4.5,26]);
if numel(tp_e_pos)~=0
    ker_len=ceil(tp_len/2)+20;
    sig_ex=[1:ker_len-length(u)+1];
    tmp=exp(-e_coef*sig_ex);
    tp_e(tp_e_pos:tp_e_pos+length(sig_ex)-1)=tmp*tp_e_a;
    tp_e=conv(tp_e,u,'same')/sum(u);
end

%noise option
if numel(tp_g_pos)~=0||numel(tp_e_pos)~=0
    tp=tp_g+tp_e;
    if noise_flag==true
        tp=tp+0.001*randn(size(tp));
        tp(find(tp<1e-5))=0;
    end
end

end